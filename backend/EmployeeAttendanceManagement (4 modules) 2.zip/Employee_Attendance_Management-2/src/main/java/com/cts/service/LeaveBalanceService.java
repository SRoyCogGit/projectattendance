package com.cts.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.dto.LeaveBalanceDTO;
import com.cts.entity.LeaveBalance;
import com.cts.entity.LeaveRequest.LeaveType;
import com.cts.repository.EmployeeRepository;
import com.cts.repository.LeaveBalanceRepository;

@Service
public class LeaveBalanceService {
    @Autowired
    private LeaveBalanceRepository leaveBalanceRepository;

    @Autowired
    private EmployeeRepository employeeRepository;

    public LeaveBalanceDTO getLeaveBalance(Long employeeId, LeaveType leaveType) {
        LeaveBalance leaveBalance = leaveBalanceRepository.findByEmployeeEmployeeIdAndLeaveType(employeeId, leaveType)
                .orElseThrow(() -> new RuntimeException("Leave balance not found"));

        return convertToDTO(leaveBalance);
    }

    public LeaveBalanceDTO updateLeaveBalance(Long employeeId, LeaveType leaveType, int leaveDays) {
    	
    	
        LeaveBalance leaveBalance = leaveBalanceRepository.findByEmployeeEmployeeIdAndLeaveType(employeeId, leaveType)
                .orElseThrow(() -> new RuntimeException("Leave balance not found"));

        if (leaveBalance.getBalance() >= leaveDays) {
            leaveBalance.setBalance(leaveBalance.getBalance() - leaveDays);
            leaveBalanceRepository.save(leaveBalance);
            return convertToDTO(leaveBalance);
        } else {
            throw new RuntimeException("Insufficient leave balance");
        }
    }

    private LeaveBalanceDTO convertToDTO(LeaveBalance leaveBalance) {
        return new LeaveBalanceDTO(
                leaveBalance.getId(),
                leaveBalance.getEmployee().getEmployeeId(),
                leaveBalance.getLeaveType(),
                leaveBalance.getBalance()
        );
    }
}

