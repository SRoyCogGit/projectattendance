package com.cts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cts.dto.ShiftDTO;
import com.cts.service.ShiftService;

@RestController
@RequestMapping("/shift")
public class ShiftController {
    @Autowired
    private ShiftService shiftService;

    @PostMapping("/assign/{employeeId}")
    public ResponseEntity<ShiftDTO> assignShift(@PathVariable Long employeeId, @RequestBody ShiftDTO dto) {
        return ResponseEntity.ok(shiftService.assignShift(employeeId, dto));
    }

    @GetMapping("/{employeeId}")
    public ResponseEntity<List<ShiftDTO>> getShifts(@PathVariable Long employeeId) {
        return ResponseEntity.ok(shiftService.getShifts(employeeId));
    }

    @PutMapping("/request-swap/{shiftId}")
    public ResponseEntity<ShiftDTO> requestSwap(@PathVariable Long shiftId) {
        return ResponseEntity.ok(shiftService.requestSwap(shiftId));
    }

    @PutMapping("/approve-swap/{shiftId}")
    public ResponseEntity<ShiftDTO> approveSwap(@PathVariable Long shiftId, @RequestParam boolean approved) {
        return ResponseEntity.ok(shiftService.approveSwap(shiftId, approved));
    }
}
