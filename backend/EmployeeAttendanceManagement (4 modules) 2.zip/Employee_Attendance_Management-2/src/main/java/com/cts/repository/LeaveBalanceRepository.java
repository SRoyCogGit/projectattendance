package com.cts.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.entity.LeaveBalance;
import com.cts.entity.LeaveRequest.LeaveType;

@Repository
public interface LeaveBalanceRepository extends JpaRepository<LeaveBalance, Long> {
    Optional<LeaveBalance> findByEmployeeEmployeeIdAndLeaveType(Long employeeId, LeaveType leaveType);
}

