package com.cts.dto;

import java.time.LocalDate;

public class ShiftDTO {
    private Long shiftId;
    private Long employeeId;
    private LocalDate shiftDate;
    private String shiftTime;
    private Boolean swapRequested;
    private Boolean approvedSwap;

    // Constructors
    public ShiftDTO() {}

    public ShiftDTO(Long shiftId, Long employeeId, LocalDate shiftDate, String shiftTime, Boolean swapRequested, Boolean approvedSwap) {
        this.shiftId = shiftId;
        this.employeeId = employeeId;
        this.shiftDate = shiftDate;
        this.shiftTime = shiftTime;
        this.swapRequested = swapRequested;
        this.approvedSwap = approvedSwap;
    }

	public Long getShiftId() {
		return shiftId;
	}

	public void setShiftId(Long shiftId) {
		this.shiftId = shiftId;
	}

	public Long getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Long employeeId) {
		this.employeeId = employeeId;
	}

	public LocalDate getShiftDate() {
		return shiftDate;
	}

	public void setShiftDate(LocalDate shiftDate) {
		this.shiftDate = shiftDate;
	}

	public String getShiftTime() {
		return shiftTime;
	}

	public void setShiftTime(String shiftTime) {
		this.shiftTime = shiftTime;
	}

	public Boolean getSwapRequested() {
		return swapRequested;
	}

	public void setSwapRequested(Boolean swapRequested) {
		this.swapRequested = swapRequested;
	}

	public Boolean getApprovedSwap() {
		return approvedSwap;
	}

	public void setApprovedSwap(Boolean approvedSwap) {
		this.approvedSwap = approvedSwap;
	}

    // Getters and Setters
    
}

