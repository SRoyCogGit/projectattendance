package com.cts.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.dto.LeaveBalanceDTO;
import com.cts.entity.LeaveRequest.LeaveType;
import com.cts.service.LeaveBalanceService;

@RestController
@RequestMapping("/leave-balance")
public class LeaveBalanceController {
    @Autowired
    private LeaveBalanceService leaveBalanceService;

    @GetMapping("/{employeeId}/{leaveType}")
    public ResponseEntity<LeaveBalanceDTO> getLeaveBalance(@PathVariable Long employeeId, @PathVariable LeaveType leaveType) {
        return ResponseEntity.ok(leaveBalanceService.getLeaveBalance(employeeId, leaveType));
    }

    @PutMapping("/update/{employeeId}/{leaveType}/{leaveDays}")
    public ResponseEntity<LeaveBalanceDTO> updateLeaveBalance(@PathVariable Long employeeId, @PathVariable LeaveType leaveType, @PathVariable int leaveDays) {
        return ResponseEntity.ok(leaveBalanceService.updateLeaveBalance(employeeId, leaveType, leaveDays));
    }
}

