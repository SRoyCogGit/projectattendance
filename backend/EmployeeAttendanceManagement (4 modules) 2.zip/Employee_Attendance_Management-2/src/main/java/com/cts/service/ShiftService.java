package com.cts.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.dto.ShiftDTO;
import com.cts.entity.Employee;
import com.cts.entity.Shift;
import com.cts.repository.EmployeeRepository;
import com.cts.repository.ShiftRepository;

@Service
public class ShiftService {
    @Autowired
    private ShiftRepository shiftRepository;

    @Autowired
    private EmployeeRepository employeeRepository;

    // Assign shift to an employee
    public ShiftDTO assignShift(Long employeeId, ShiftDTO dto) {
        Employee employee = employeeRepository.findById(employeeId)
                .orElseThrow(() -> new RuntimeException("Employee not found"));

        Shift shift = new Shift();
        shift.setEmployee(employee);
        shift.setShiftDate(dto.getShiftDate());
        shift.setShiftTime(dto.getShiftTime());
        shift.setSwapRequested(false);
        shift.setApprovedSwap(false);

        shiftRepository.save(shift);
        return convertToDTO(shift);
    }

    // Employees view assigned shifts
    public List<ShiftDTO> getShifts(Long employeeId) {
        List<Shift> shifts = shiftRepository.findByEmployeeEmployeeId(employeeId);
        return shifts.stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    // Employees request shift swap
    public ShiftDTO requestSwap(Long shiftId) {
        Shift shift = shiftRepository.findById(shiftId)
                .orElseThrow(() -> new RuntimeException("Shift not found"));

        shift.setSwapRequested(true);
        shiftRepository.save(shift);
        
        return convertToDTO(shift);
    }

    // Managers approve or reject shift swap requests
    public ShiftDTO approveSwap(Long shiftId, boolean approved) {
        Shift shift = shiftRepository.findById(shiftId)
                .orElseThrow(() -> new RuntimeException("Shift not found"));

        if (!shift.getSwapRequested()) {
            throw new RuntimeException("No swap request found for this shift");
        }

        shift.setApprovedSwap(approved);
        shiftRepository.save(shift);
        
        return convertToDTO(shift);
    }

    private ShiftDTO convertToDTO(Shift shift) {
        return new ShiftDTO(
                shift.getShiftId(),
                shift.getEmployee().getEmployeeId(),
                shift.getShiftDate(),
                shift.getShiftTime(),
                shift.getSwapRequested(),
                shift.getApprovedSwap()
        );
    }
}

