package com.cts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cts.dto.LeaveRequestDTO;
import com.cts.entity.LeaveRequest.LeaveStatus;
import com.cts.service.LeaveRequestService;

@RestController
@RequestMapping("/leave")
public class LeaveRequestController {
    @Autowired
    private LeaveRequestService leaveRequestService;

    @PostMapping("/request/{employeeId}")
    public ResponseEntity<LeaveRequestDTO> requestLeave(@PathVariable Long employeeId, @RequestBody LeaveRequestDTO dto) {
        return ResponseEntity.ok(leaveRequestService.requestLeave(employeeId, dto));
    }

    @PutMapping("/approve-reject/{leaveId}")
    public ResponseEntity<LeaveRequestDTO> approveOrRejectLeave(@PathVariable Long leaveId, @RequestParam LeaveStatus status) {
        return ResponseEntity.ok(leaveRequestService.approveOrRejectLeave(leaveId, status));
    }

    @GetMapping("/{employeeId}")
    public ResponseEntity<List<LeaveRequestDTO>> getLeaveRequests(@PathVariable Long employeeId) {
        return ResponseEntity.ok(leaveRequestService.getLeaveRequests(employeeId));
    }
}
