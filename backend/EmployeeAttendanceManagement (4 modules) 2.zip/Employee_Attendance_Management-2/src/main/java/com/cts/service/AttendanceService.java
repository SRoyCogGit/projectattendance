package com.cts.service;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.dto.AttendanceDTO;
import com.cts.entity.Attendance;
import com.cts.entity.Employee;
import com.cts.repository.AttendanceRepository;
import com.cts.repository.EmployeeRepository;

@Service
public class AttendanceService {
    @Autowired
    private AttendanceRepository attendanceRepository;

    @Autowired
    private EmployeeRepository employeeRepository;

    public AttendanceDTO clockIn(Long employeeId) {
        Employee employee = employeeRepository.findById(employeeId)
                .orElseThrow(() -> new RuntimeException("Employee not found"));

        Attendance attendance = new Attendance();
        attendance.setEmployee(employee);
        attendance.setClockInTime(LocalDateTime.now());

        attendanceRepository.save(attendance);
        return convertToDTO(attendance);
    }

    public AttendanceDTO clockOut(Long attendanceId) {
        Attendance attendance = attendanceRepository.findById(attendanceId)
                .orElseThrow(() -> new RuntimeException("Attendance record not found"));

        attendance.setClockOutTime(LocalDateTime.now());
        attendance.setWorkHours((double)Duration.between(attendance.getClockInTime(), attendance.getClockOutTime()).toHours());

        attendanceRepository.save(attendance);
        return convertToDTO(attendance);
    }

    public List<AttendanceDTO> getAttendanceRecords(Long employeeId) {
        List<Attendance> attendanceList = attendanceRepository.findByEmployeeEmployeeId(employeeId);
        return attendanceList.stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    private AttendanceDTO convertToDTO(Attendance attendance) {
        return new AttendanceDTO(
                attendance.getAttendanceId(),
                attendance.getEmployee().getEmployeeId(),
                attendance.getClockInTime(),
                attendance.getClockOutTime(),
                attendance.getWorkHours()
        );
    }
}
