package com.cts.entity;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "shift")
public class Shift {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long shiftId;

    @ManyToOne
    @JoinColumn(name = "employee_id", nullable = false)
    private Employee employee;

    private LocalDate shiftDate;
    private String shiftTime;

    private Boolean swapRequested; // Employees request swap
    private Boolean approvedSwap; // Managers approve swap
	public Long getShiftId() {
		return shiftId;
	}
	public void setShiftId(Long shiftId) {
		this.shiftId = shiftId;
	}
	public Employee getEmployee() {
		return employee;
	}
	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
	public LocalDate getShiftDate() {
		return shiftDate;
	}
	public void setShiftDate(LocalDate shiftDate) {
		this.shiftDate = shiftDate;
	}
	public String getShiftTime() {
		return shiftTime;
	}
	public void setShiftTime(String shiftTime) {
		this.shiftTime = shiftTime;
	}
	public Boolean getSwapRequested() {
		return swapRequested;
	}
	public void setSwapRequested(Boolean swapRequested) {
		this.swapRequested = swapRequested;
	}
	public Boolean getApprovedSwap() {
		return approvedSwap;
	}
	public void setApprovedSwap(Boolean approvedSwap) {
		this.approvedSwap = approvedSwap;
	}

    // Getters and Setters
    
    
}

