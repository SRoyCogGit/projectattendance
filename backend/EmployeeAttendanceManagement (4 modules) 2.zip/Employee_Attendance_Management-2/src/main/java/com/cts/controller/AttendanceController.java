package com.cts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.dto.AttendanceDTO;
import com.cts.service.AttendanceService;

@RestController
@RequestMapping("/attendance")
public class AttendanceController {
    @Autowired
    private AttendanceService attendanceService;

    @PostMapping("/clock-in/{employeeId}")
    public ResponseEntity<AttendanceDTO> clockIn(@PathVariable Long employeeId) {
        return ResponseEntity.ok(attendanceService.clockIn(employeeId));
    }

    @PutMapping("/clock-out/{attendanceId}")
    public ResponseEntity<AttendanceDTO> clockOut(@PathVariable Long attendanceId) {
        return ResponseEntity.ok(attendanceService.clockOut(attendanceId));
    }

    @GetMapping("/{employeeId}")
    public ResponseEntity<List<AttendanceDTO>> getAttendanceRecords(@PathVariable Long employeeId) {
        List<AttendanceDTO> records = attendanceService.getAttendanceRecords(employeeId);
        return ResponseEntity.ok(records);  // Ensure it's only wrapped once
    }
}

