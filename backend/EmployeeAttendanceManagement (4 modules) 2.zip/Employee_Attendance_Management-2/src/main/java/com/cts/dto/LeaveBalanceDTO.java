package com.cts.dto;

import com.cts.entity.LeaveRequest.LeaveType;

public class LeaveBalanceDTO {
    private Long id;
    private Long employeeId;
    private LeaveType leaveType;
    private Integer balance;

    // Constructors
    public LeaveBalanceDTO() {}

    public LeaveBalanceDTO(Long id, Long employeeId, LeaveType leaveType, Integer balance) {
        this.id = id;
        this.employeeId = employeeId;
        this.leaveType = leaveType;
        this.balance = balance;
    }

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Long employeeId) {
		this.employeeId = employeeId;
	}

	public LeaveType getLeaveType() {
		return leaveType;
	}

	public void setLeaveType(LeaveType leaveType) {
		this.leaveType = leaveType;
	}

	public Integer getBalance() {
		return balance;
	}

	public void setBalance(Integer balance) {
		this.balance = balance;
	}

    // Getters and Setters
    
    
}

